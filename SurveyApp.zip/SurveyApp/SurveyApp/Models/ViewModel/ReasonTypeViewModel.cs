﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SurveyApp.Models.ViewModel
{
    public class ReasonTypeViewModel : ViewModelComon
    {
        public int ReasonTypeId { get; set; }
        public string ReasonName { get; set; }
    }
}