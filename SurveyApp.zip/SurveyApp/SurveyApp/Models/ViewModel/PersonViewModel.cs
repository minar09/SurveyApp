﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SurveyApp.Models.ViewModel
{
    public class PersonViewModel : ViewModelComon
    {
        public int PersonId { get; set; }
        public string Name { get; set; }
        public string NationalId { get; set; }
        public string BirthId { get; set; }
        public Nullable<System.DateTime> BirthDate { get; set; }
        public string FathersName { get; set; }
        public string MothersName { get; set; }
        public string LocationName { get; set; }
    }
}