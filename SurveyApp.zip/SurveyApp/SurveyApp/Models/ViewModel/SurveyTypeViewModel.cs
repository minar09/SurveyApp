﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SurveyApp.Models.ViewModel
{
    public class SurveyTypeViewModel : ViewModelComon
    {
        public int SurveyTypeId { get; set; }
        public string SurveyName { get; set; }
    }
}