﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SurveyApp.Models.ViewModel
{
    public class ViewModelComon
    {
        public Nullable<System.DateTime> CreateDate { get; set; }
        public Nullable<int> InsertedById { get; set; }
        public string InsertedByName { get; set; }
        public Nullable<System.DateTime> UpdateDate { get; set; }
        public Nullable<int> UpdatedById { get; set; }
        public string UpdatedByName { get; set; }
    }
}