﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SurveyApp.Models.ViewModel
{
    public class SurveyDetailViewModel : ViewModelComon
    {
        public int SurveyDetailId { get; set; }
        public Nullable<int> PersonId { get; set; }
        public string Name { get; set; }
        public Nullable<int> SurveyTypeId { get; set; }
        public string SurveyName { get; set; }
        public Nullable<bool> Status { get; set; }
        public Nullable<int> ReasonTypeId { get; set; }
        public string ReasonName { get; set; }
    }
}