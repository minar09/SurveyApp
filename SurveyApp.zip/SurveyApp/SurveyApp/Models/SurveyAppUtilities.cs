﻿using SurveyApp.Models.DBModel;
using SurveyApp.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SurveyApp.Models
{
    public class SurveyAppUtilities
    {
        public class Constants
        {
            public const string SiteName = "Survey App";

            public static int RowPerPage = 5;
        }


        internal static void NewMethod(List<UserAdmin> userAdminList, ReasonTypeViewModel aSurveyDetailViewModel, ReasonType item)
        {
            aSurveyDetailViewModel.CreateDate = item.CreateDate;

            aSurveyDetailViewModel.InsertedById = item.InsertedById;
            UserAdmin userAdmin = userAdminList.Find(x => x.AdminUserId == item.InsertedById);

            if (userAdmin != null)
            {
                aSurveyDetailViewModel.InsertedByName = userAdmin.Name;
            }

            aSurveyDetailViewModel.UpdateDate = item.UpdateDate;

            aSurveyDetailViewModel.UpdatedById = item.UpdatedById;

            UserAdmin userAdminForUpdate = userAdminList.Find(x => x.AdminUserId == item.UpdatedById);
            if (userAdminForUpdate != null)
            {
                aSurveyDetailViewModel.UpdatedByName = userAdminForUpdate.Name;
            }
        }
        internal static List<SelectListItem> GetSurveyTypeAsSelectListItem(List<SurveyType> surveyTypeList)
        {
            List<SelectListItem> listSelectListItem = new List<SelectListItem>();
            foreach (SurveyType item in surveyTypeList)
            {
                SelectListItem a = new SelectListItem();
                a.Text = item.SurveyName;
                a.Value = item.SurveyTypeId.ToString();

                listSelectListItem.Add(a);
            }

            return listSelectListItem;
        }

        internal static List<SelectListItem> GetReasonTypeAsSelectListItem(List<ReasonType> reasonTypeList)
        {
            List<SelectListItem> listSelectListItem = new List<SelectListItem>();
            foreach (ReasonType item in reasonTypeList)
            {
                SelectListItem a = new SelectListItem();
                a.Text = item.ReasonName;
                a.Value = item.ReasonTypeId.ToString();

                listSelectListItem.Add(a);
            }

            return listSelectListItem;
        }

        internal static List<SelectListItem> GetPersonAsSelectListItem(List<Person> personList)
        {
            List<SelectListItem> listSelectListItem = new List<SelectListItem>();

            foreach (Person item in personList)
            {
                SelectListItem a = new SelectListItem();
                a.Text = item.Name;
                a.Value = item.PersonId.ToString();

                listSelectListItem.Add(a);
            }

            return listSelectListItem;
        }

        
    }
}