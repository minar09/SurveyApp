﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SurveyApp.Models.DBModel;
using System.Web.Mvc;
namespace SurveyApp.Models.BLL
{
    public class UserAdminBLL
    {
        internal void CreateNewAdminUserByUserName(string userName)
        {
            UserAdmin newUserAdmin = new UserAdmin();

            newUserAdmin.UserName = userName;
            SurveyAppDbEntities db = new SurveyAppDbEntities();

            db.UserAdmins.Add(newUserAdmin);
            db.SaveChanges();
        }
    }
}