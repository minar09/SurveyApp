﻿using SurveyApp.Models.DBModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SurveyApp.Models.BLL
{
    public class PolioSurveyBLL
    {
        SurveyAppDbEntities db = new SurveyAppDbEntities();

      
    }
}