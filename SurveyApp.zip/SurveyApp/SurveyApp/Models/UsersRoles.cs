﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SurveyApp.Models
{
    public class UsersRoles
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}