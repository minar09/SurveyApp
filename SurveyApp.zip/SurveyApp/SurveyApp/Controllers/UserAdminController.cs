﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SurveyApp.Models.DBModel;

namespace SurveyApp.Controllers
{
    [Authorize]
    public class UserAdminController : Controller
    {
        private SurveyAppDbEntities db = new SurveyAppDbEntities();

        //
        // GET: /UserAdmin/

        public ActionResult Index()
        {
            return View(db.UserAdmins.ToList());
        }

        //
        // GET: /UserAdmin/Details/5

        public ActionResult Details(int id = 0)
        {
            UserAdmin useradmin = db.UserAdmins.Find(id);
            if (useradmin == null)
            {
                return HttpNotFound();
            }
            return View(useradmin);
        }

        //
        // GET: /UserAdmin/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /UserAdmin/Create

        [HttpPost]
        public ActionResult Create(UserAdmin anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.CreateDate = now;
                anObject.InsertedById = userId;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;

                db.UserAdmins.Add(anObject);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(anObject);
        }

        //
        // GET: /UserAdmin/Edit/5

        public ActionResult Edit(int id = 0)
        {
            UserAdmin useradmin = db.UserAdmins.Find(id);

            if (useradmin == null)
            {
                useradmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);

            }
            return View(useradmin);
        }

        //
        // POST: /UserAdmin/Edit/5

        [HttpPost]
        public ActionResult Edit(UserAdmin anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;


                db.Entry(anObject).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(anObject);
        }

        //
        // GET: /UserAdmin/Delete/5

        public ActionResult Delete(int id = 0)
        {
            UserAdmin useradmin = db.UserAdmins.Find(id);
            if (useradmin == null)
            {
                return HttpNotFound();
            }
            return View(useradmin);
        }

        //
        // POST: /UserAdmin/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            UserAdmin useradmin = db.UserAdmins.Find(id);
            db.UserAdmins.Remove(useradmin);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}