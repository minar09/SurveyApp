﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SurveyApp.Models.DBModel;
using SurveyApp.Models;
using SurveyApp.Models.ViewModel;

namespace SurveyApp.Controllers
{
    [Authorize]
    public class SurveyController : Controller
    {
        private SurveyAppDbEntities db = new SurveyAppDbEntities();

        //
        // GET: /Survey/
        public ActionResult Index()
        {
            ViewBag.TestData = 22;
            List<SurveyDetailViewModel> viewModelList = new List<SurveyDetailViewModel>();

            List<SurveyDetail> surveyDetailList = db.SurveyDetails.ToList();
            List<Person> personList = db.People.ToList();
            List<SurveyType> surveyTypeList = db.SurveyTypes.ToList();
            List<ReasonType> reasonTypeList = db.ReasonTypes.ToList();
            List<UserAdmin> userAdminList = db.UserAdmins.ToList();

            SurveyDetailViewModel aSurveyDetailViewModel = null;

            foreach (SurveyDetail item in surveyDetailList)
            {
                aSurveyDetailViewModel = new SurveyDetailViewModel();

                aSurveyDetailViewModel.SurveyDetailId = item.SurveyDetailId;

                aSurveyDetailViewModel.PersonId = item.PersonId;
                Person person = personList.Find(x => x.PersonId == item.PersonId);
                if (person != null)
                {
                    aSurveyDetailViewModel.Name = person.Name;
                }

                aSurveyDetailViewModel.SurveyTypeId = item.SurveyTypeId;
                SurveyType surveyType = surveyTypeList.Find(x => x.SurveyTypeId == item.SurveyTypeId);
                if (surveyType != null)
                {
                    aSurveyDetailViewModel.SurveyName = surveyType.SurveyName;
                }
                aSurveyDetailViewModel.Status = item.Status;

                aSurveyDetailViewModel.ReasonTypeId = item.ReasonTypeId;
                ReasonType reasonType = reasonTypeList.Find(x => x.ReasonTypeId == item.ReasonTypeId);
                if (reasonType != null)
                {
                    aSurveyDetailViewModel.ReasonName = reasonType.ReasonName;
                }

                aSurveyDetailViewModel.CreateDate = item.CreateDate;

                aSurveyDetailViewModel.InsertedById = item.InsertedById;
                UserAdmin userAdmin = userAdminList.Find(x => x.AdminUserId == item.InsertedById);
                if (userAdmin != null)
                {
                    aSurveyDetailViewModel.InsertedByName = userAdmin.Name;
                }

                aSurveyDetailViewModel.UpdateDate = item.UpdateDate;

                aSurveyDetailViewModel.UpdatedById = item.UpdatedById;

                UserAdmin userAdminForUpdate = userAdminList.Find(x => x.AdminUserId == item.UpdatedById);
                if (userAdminForUpdate != null)
                {
                    aSurveyDetailViewModel.UpdatedByName = userAdminForUpdate.Name;
                }

                viewModelList.Add(aSurveyDetailViewModel);
            }
            return View(viewModelList);
        }

        //
        // GET: /Survey/Details/5

        public ActionResult Details(int id = 0)
        {
            SurveyDetail surveydetail = db.SurveyDetails.Find(id);
            if (surveydetail == null)
            {
                return HttpNotFound();
            }
            return View(surveydetail);
        }

        //
        // GET: /Survey/Create
        public ActionResult Create(int id = 0)
        {
            List<Person> personList = (from person in db.People
                                       where person.PersonId == id
                                       select person).ToList();

            if (personList == null || personList.Count <= 0)
            {
                return HttpNotFound();
            }

            ViewBag.personSelectListItem = personList;
            List<SurveyType> surveyTypeList = db.SurveyTypes.ToList();
            ViewBag.surveyTypeSelectListItem = surveyTypeList;
            List<ReasonType> reasonTypeList = db.ReasonTypes.ToList();
            ViewBag.ReasonTypeSelectListItemList = reasonTypeList;

            return View(new SurveyDetail());
        }

        //
        // POST: /Survey/Create

        [HttpPost]
        public ActionResult Create(SurveyDetail anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.CreateDate = now;
                anObject.InsertedById = userId;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;

                db.SurveyDetails.Add(anObject);
                db.SaveChanges();
                return RedirectToAction("Index", "Person");
            }

            return View(anObject);
        }

        //
        // GET: /Survey/Edit/5
        public ActionResult Edit(int id = 0)
        {
            SurveyDetail surveydetail = db.SurveyDetails.Find(id);
            if (surveydetail == null)
            {
                return HttpNotFound();
            }

            List<Person> personList = (from person in db.People
                                       where person.PersonId == id
                                       select person).ToList();

            ViewBag.personSelectListItem = personList;
            List<SurveyType> surveyTypeList = db.SurveyTypes.ToList();
            ViewBag.surveyTypeSelectListItem = surveyTypeList;
            List<ReasonType> reasonTypeList = db.ReasonTypes.ToList();
            ViewBag.ReasonTypeSelectListItemList = reasonTypeList;

            return View(surveydetail);
        }

        //
        // POST: /Survey/Edit/5

        [HttpPost]
        public ActionResult Edit(SurveyDetail anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;

                db.Entry(anObject).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(anObject);
        }

        //
        // GET: /Survey/Delete/5
        [Authorize(Roles = UsersRoles.Admin)]
        public ActionResult Delete(int id = 0)
        {
            SurveyDetail surveydetail = db.SurveyDetails.Find(id);
            if (surveydetail == null)
            {
                return HttpNotFound();
            }
            return View(surveydetail);
        }

        //
        // POST: /Survey/Delete/5
        [Authorize(Roles = UsersRoles.Admin)]
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            SurveyDetail surveydetail = db.SurveyDetails.Find(id);
            db.SurveyDetails.Remove(surveydetail);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [AllowAnonymous]
        public ActionResult GetAutoCompletionforName()
        {
            List<Person> list = db.People.ToList();

            var datajson = new
            {
                rows = (from c in list
                        select new
                        {
                            cell = new string[] 
                                            {
                                              System.Convert.ToString(c.Name)
                                              }
                        }).ToArray()
            };

            return Json(datajson, JsonRequestBehavior.AllowGet);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}