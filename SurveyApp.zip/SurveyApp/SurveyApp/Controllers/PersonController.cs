﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SurveyApp.Models.DBModel;
using SurveyApp.Models;
using SurveyApp.Models.ViewModel;

namespace SurveyApp.Controllers
{
    [Authorize]
    public class PersonController : Controller
    {
        private SurveyAppDbEntities db = new SurveyAppDbEntities();

        //
        // GET: /Person/

        public ActionResult Index()
        {
            List<PersonViewModel> viewModelList = new List<PersonViewModel>();
            List<Person> personList = db.People.ToList();
            List<SurveyType> surveyTypeList = db.SurveyTypes.ToList();
            List<UserAdmin> userAdminList = db.UserAdmins.ToList();
            PersonViewModel aPersonViewModel = null;

            foreach (Person item in personList)
            {
                aPersonViewModel = new PersonViewModel();

                aPersonViewModel.PersonId = item.PersonId;

                aPersonViewModel.Name = item.Name;
                aPersonViewModel.NationalId = item.NationalId;
                aPersonViewModel.BirthId = item.BirthId;
                aPersonViewModel.BirthDate = item.BirthDate;
                aPersonViewModel.FathersName = item.FathersName;
                aPersonViewModel.MothersName = item.MothersName;
                aPersonViewModel.LocationName = item.LocationName;
                                
                aPersonViewModel.CreateDate = item.CreateDate;

                aPersonViewModel.InsertedById = item.InsertedById;
                UserAdmin userAdmin = userAdminList.Find(x => x.AdminUserId == item.InsertedById);

                if (userAdmin != null)
                {
                    aPersonViewModel.InsertedByName = userAdmin.Name;
                }

                aPersonViewModel.UpdateDate = item.UpdateDate;

                aPersonViewModel.UpdatedById = item.UpdatedById;

                UserAdmin userAdminForUpdate = userAdminList.Find(x => x.AdminUserId == item.UpdatedById);
                if (userAdminForUpdate != null)
                {
                    aPersonViewModel.UpdatedByName = userAdminForUpdate.Name;
                }

                viewModelList.Add(aPersonViewModel);
            }
            return View(viewModelList);
        }

        //
        // GET: /Person/Details/5

        public ActionResult Details(int id = 0)
        {
            Person person = db.People.Find(id);
            if (person == null)
            {
                return HttpNotFound();
            }
            return View(person);
        }

        //
        // GET: /Person/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Person/Create

        [HttpPost]
        public ActionResult Create(Person anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.CreateDate = now;
                anObject.InsertedById = userId;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;

                db.People.Add(anObject);
                db.SaveChanges();

                return RedirectToAction("Create", "Survey", new { id = anObject.PersonId });
            }

            return View(anObject);
        }

        //
        // GET: /Person/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Person person = db.People.Find(id);
            if (person == null)
            {
                return HttpNotFound();
            }
            return View(person);
        }

        //
        // POST: /Person/Edit/5

        [HttpPost]
        public ActionResult Edit(Person anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;

                db.Entry(anObject).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(anObject);
        }

        //
        // GET: /Person/Delete/5
        [Authorize(Roles = UsersRoles.Admin)]
        public ActionResult Delete(int id = 0)
        {
            Person person = db.People.Find(id);
            if (person == null)
            {
                return HttpNotFound();
            }
            return View(person);
        }

        //
        // POST: /Person/Delete/5
        [Authorize(Roles = UsersRoles.Admin)]
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Person person = db.People.Find(id);
            db.People.Remove(person);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}