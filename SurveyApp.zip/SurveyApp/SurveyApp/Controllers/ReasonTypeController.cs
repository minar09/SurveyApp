﻿using SurveyApp.Models;
using SurveyApp.Models.DBModel;
using SurveyApp.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace SurveyApp.Controllers
{
    [Authorize]
    public class ReasonTypeController : Controller
    {
        private SurveyAppDbEntities db = new SurveyAppDbEntities();

        //
        // GET: /ReasonType/

        public ActionResult Index()
        {
            List<ReasonTypeViewModel> viewModelList = new List<ReasonTypeViewModel>();
            List<ReasonType> reasonTypeList = db.ReasonTypes.ToList();
            List<SurveyType> surveyTypeList = db.SurveyTypes.ToList();
            List<UserAdmin> userAdminList = db.UserAdmins.ToList();
            ReasonTypeViewModel aSurveyDetailViewModel = null;

            foreach (ReasonType item in reasonTypeList)
            {
                aSurveyDetailViewModel = new ReasonTypeViewModel();

                aSurveyDetailViewModel.ReasonTypeId = item.ReasonTypeId;

                aSurveyDetailViewModel.ReasonName = item.ReasonName;

                aSurveyDetailViewModel.CreateDate = item.CreateDate;

                aSurveyDetailViewModel.InsertedById = item.InsertedById;
                UserAdmin userAdmin = userAdminList.Find(x => x.AdminUserId == item.InsertedById);

                if (userAdmin != null)
                {
                    aSurveyDetailViewModel.InsertedByName = userAdmin.Name;
                }

                aSurveyDetailViewModel.UpdateDate = item.UpdateDate;

                aSurveyDetailViewModel.UpdatedById = item.UpdatedById;

                UserAdmin userAdminForUpdate = userAdminList.Find(x => x.AdminUserId == item.UpdatedById);
                if (userAdminForUpdate != null)
                {
                    aSurveyDetailViewModel.UpdatedByName = userAdminForUpdate.Name;
                }

                viewModelList.Add(aSurveyDetailViewModel);
            }

            return View(viewModelList);
        }

        //
        // GET: /ReasonType/Details/5

        public ActionResult Details(int id = 0)
        {
            ReasonType reasontype = db.ReasonTypes.Find(id);
            if (reasontype == null)
            {
                return HttpNotFound();
            }
            return View(reasontype);
        }

        //
        // GET: /ReasonType/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /ReasonType/Create

        [HttpPost]
        public ActionResult Create(ReasonType anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.CreateDate = now;
                anObject.InsertedById = userId;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;

                db.ReasonTypes.Add(anObject);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(anObject);
        }

        //
        // GET: /ReasonType/Edit/5

        public ActionResult Edit(int id = 0)
        {
            ReasonType reasontype = db.ReasonTypes.Find(id);
            if (reasontype == null)
            {
                return HttpNotFound();
            }
            return View(reasontype);
        }

        //
        // POST: /ReasonType/Edit/5

        [HttpPost]
        public ActionResult Edit(ReasonType anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;

                db.Entry(anObject).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(anObject);
        }

        //
        // GET: /ReasonType/Delete/5

        public ActionResult Delete(int id = 0)
        {
            ReasonType reasontype = db.ReasonTypes.Find(id);
            if (reasontype == null)
            {
                return HttpNotFound();
            }
            return View(reasontype);
        }

        //
        // POST: /ReasonType/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            ReasonType reasontype = db.ReasonTypes.Find(id);
            db.ReasonTypes.Remove(reasontype);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}