﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SurveyApp.Models.DBModel;
using SurveyApp.Models.ViewModel;
using SurveyApp.Models;

namespace SurveyApp.Controllers
{
    [Authorize]
    public class SurveyTypeController : Controller
    {
        private SurveyAppDbEntities db = new SurveyAppDbEntities();

        //
        // GET: /SurveyType/

        public ActionResult Index()
        {
            List<SurveyTypeViewModel> viewModelList = new List<SurveyTypeViewModel>();

            List<SurveyType> surveyTypeList = db.SurveyTypes.ToList();
            List<UserAdmin> userAdminList = db.UserAdmins.ToList();
            SurveyTypeViewModel aSurveyDetailViewModel = null;

            foreach (SurveyType item in surveyTypeList)
            {
                aSurveyDetailViewModel = new SurveyTypeViewModel();

                aSurveyDetailViewModel.SurveyTypeId = item.SurveyTypeId;

                aSurveyDetailViewModel.SurveyName = item.SurveyName;

                aSurveyDetailViewModel.CreateDate = item.CreateDate;

                aSurveyDetailViewModel.InsertedById = item.InsertedById;
                UserAdmin userAdmin = userAdminList.Find(x => x.AdminUserId == item.InsertedById);

                if (userAdmin != null)
                {
                    aSurveyDetailViewModel.InsertedByName = userAdmin.Name;
                }

                aSurveyDetailViewModel.UpdateDate = item.UpdateDate;

                aSurveyDetailViewModel.UpdatedById = item.UpdatedById;

                UserAdmin userAdminForUpdate = userAdminList.Find(x => x.AdminUserId == item.UpdatedById);
                if (userAdminForUpdate != null)
                {
                    aSurveyDetailViewModel.UpdatedByName = userAdminForUpdate.Name;
                }

                viewModelList.Add(aSurveyDetailViewModel);
            }
            return View(viewModelList);
        }

        //
        // GET: /SurveyType/Details/5

        public ActionResult Details(int id = 0)
        {
            SurveyType surveytype = db.SurveyTypes.Find(id);
            if (surveytype == null)
            {
                return HttpNotFound();
            }
            return View(surveytype);
        }

        //
        // GET: /SurveyType/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /SurveyType/Create

        [HttpPost]
        public ActionResult Create(SurveyType anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.CreateDate = now;
                anObject.InsertedById = userId;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;


                db.SurveyTypes.Add(anObject);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(anObject);
        }

        //
        // GET: /SurveyType/Edit/5

        public ActionResult Edit(int id = 0)
        {
            SurveyType surveytype = db.SurveyTypes.Find(id);
            if (surveytype == null)
            {
                return HttpNotFound();
            }
            return View(surveytype);
        }

        //
        // POST: /SurveyType/Edit/5

        [HttpPost]
        public ActionResult Edit(SurveyType anObject)
        {
            if (ModelState.IsValid)
            {
                int userId = 0;
                UserAdmin aUserAdmin = db.UserAdmins.FirstOrDefault(x => x.UserName == User.Identity.Name);
                if (aUserAdmin != null)
                {
                    userId = aUserAdmin.AdminUserId;
                }

                DateTime now = DateTime.Now;
                anObject.UpdateDate = now;
                anObject.UpdatedById = userId;


                db.Entry(anObject).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(anObject);
        }

        //
        // GET: /SurveyType/Delete/5

        public ActionResult Delete(int id = 0)
        {
            SurveyType surveytype = db.SurveyTypes.Find(id);
            if (surveytype == null)
            {
                return HttpNotFound();
            }
            return View(surveytype);
        }

        //
        // POST: /SurveyType/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            SurveyType surveytype = db.SurveyTypes.Find(id);
            db.SurveyTypes.Remove(surveytype);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}